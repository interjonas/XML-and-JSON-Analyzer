﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.IO;
using System.Xml;
using System.Web.Script.Serialization;
//using System.Net.Http;
//using Newtonsoft.Json;

namespace hw41
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public XmlDocument doc = new XmlDocument();
        public XmlNode node;
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string file = TextBox3.Text;
            doc.Load(file);
            node = doc.DocumentElement;
            //TextBox4.Text = TextBox4.Text+node.NodeType.ToString();
            //TextBox4.Text = TextBox4.Text + " " + Convert.ToString(node.Name) +" " +Convert.ToString(node.Value)+"\n";
            findAllNodes(node);
            attribute(node);
            //XmlAttributeCollection = node;//node.Attributes;
        }
        public void OutputNode(XmlNode node)
        {
            if (node == null)
            {
                TextBox4.Text = TextBox4.Text + node.NodeType.ToString();
                TextBox4.Text = TextBox4.Text + " " + Convert.ToString(node.Name) + " " + Convert.ToString(node.Value) + "\n";
            }
            if (node.HasChildNodes)
            {
                XmlNodeList children = node.ChildNodes;
                foreach (XmlNode child in children)
                {
                    OutputNode(child);
                }
            }
        }
        public void findAllNodes(XmlNode node)
        {
            TextBox4.Text = TextBox4.Text + node.NodeType.ToString() + " " + Convert.ToString(node.Name) + " " + Convert.ToString(node.Value) + "\n";
            foreach (XmlNode n in node.ChildNodes)
            {
                findAllNodes(n);
            }
        }
        public void attribute(XmlNode node)
        {
            TextBox4.Text = TextBox4.Text + "\n\n";
            foreach (XmlNode n in node.ChildNodes)
            {
                //attribute(n);
                TextBox4.Text = TextBox4.Text + node.NodeType.ToString() + " " + Convert.ToString(node.Name) + " " + Convert.ToString(node.Value) + "\n";
                foreach (XmlAttribute att in n.Attributes)
                {
                    TextBox4.Text = TextBox4.Text + att.Name.ToString() +att.Value.ToString() + "\n";
                }
            }
        }
    }
}