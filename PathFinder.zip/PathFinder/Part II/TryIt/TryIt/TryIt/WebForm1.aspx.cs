﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Xml.XPath;

namespace hw41
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public XmlDocument doc = new XmlDocument();
        public XmlNode node;
        protected void Page_Load(object sender, EventArgs e)
        {
         

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //ServiceReference1.Service1Client verify = new ServiceReference1.Service1Client();
            string xml = TextBox1.Text;
            string schema = TextBox2.Text;
            string result = verify(xml,schema);// verify.verify(xml, schema);
            Label1.Text = result;
        }
        public string verify(string xmlURL, string schemaURL)
        {
            bool status = true;
            string output = "";
            try
            {
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.Schemas.Add(null, schemaURL);
                settings.ValidationType = ValidationType.Schema;
                settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessInlineSchema;
                settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessSchemaLocation;
                settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
                settings.IgnoreWhitespace = true;
                XmlReader book = XmlReader.Create(xmlURL, settings);
                XmlDocument document = new XmlDocument();
                document.Load(book);
                ValidationEventHandler eventHandler = new ValidationEventHandler(validate);
                document.Validate(eventHandler);
            }
            catch (Exception err)
            {
                status = false;
                output = "ISSUE DETECTED: " + err.Message;
            }
            if (status)
            {
                output = "No Error";
            }
            return output;
        }
        public static void validate(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Warning)
            {
                Console.WriteLine("Warning" + e.Message);
            }
            else
            {
                Console.WriteLine("Error message " + e.Message);
            }
        }
        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //ServiceReference2.Service1Client path = new ServiceReference2.Service1Client();
            string xml = TextBox3.Text;
            string inputpath = TextBox4.Text;
            string result = path(xml,inputpath);// path.path(xml, inputpath);
            TextBox5.Text = result;
        }
        public string path(string xmlURL, string path)
        {
            XPathDocument dx = new XPathDocument(xmlURL);
            Console.WriteLine(dx);
            XPathNavigator nav = dx.CreateNavigator();
            string output = "";
            XPathNodeIterator iterator = nav.Select(path);
            while (iterator.MoveNext())
            {
                string value = iterator.Current.Value;
                output = output + value + "\n";
            }
            return output;
        }

    }
}