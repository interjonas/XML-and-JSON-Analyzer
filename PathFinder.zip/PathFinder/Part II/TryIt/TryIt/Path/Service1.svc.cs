﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.XPath;
using System.IO;

namespace Homework1
{
    public class Service1 : IService1
    {
        public string path(string xmlURL, string path)
        {
            XPathDocument dx = new XPathDocument(xmlURL);
            Console.WriteLine(dx);
            XPathNavigator nav = dx.CreateNavigator();
            string output = " ";
            XPathNodeIterator iterator = nav.Select(path);
            while (iterator.MoveNext())
            {
                string value = iterator.Current.Value;
                output = " " + output + value + " ";
            }
            return output;
        }
    }
}