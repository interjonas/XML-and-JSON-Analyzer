﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using System.IO;

namespace Homework1
{
    public class Service1 : IService1
    {
        public string verify(string xmlURL, string schemaURL)
        {
            bool status = true;
            string output = "";
            try
            {
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.Schemas.Add(null, schemaURL);
                settings.ValidationType = ValidationType.Schema;
                settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessInlineSchema;
                settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessSchemaLocation;
                settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
                settings.IgnoreWhitespace = true;
                XmlReader book = XmlReader.Create(xmlURL, settings);
                XmlDocument document = new XmlDocument();
                document.Load(book);
                ValidationEventHandler eventHandler = new ValidationEventHandler(validate);
                document.Validate(eventHandler);
            }
            catch (Exception err)
            {
                status = false;
                output = "ISSUE DETECTED: " + err.Message;
            }
            if (status)
            {
                output = "No Error";
            }
            return output;
        }
        public static void validate(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Warning)
            {
                Console.WriteLine("Warning" + e.Message);
            }
            else
            {
                Console.WriteLine("Error message " + e.Message);
            }
        }
    }
}